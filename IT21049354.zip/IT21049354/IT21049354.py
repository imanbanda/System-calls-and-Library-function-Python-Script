#IT21049354
#A.M.I.R.B.Athauda
#SOS Assignment 2

import getpass
import os
from datetime import datetime
import calendar
import platform

#Printing currently logged in User
print("Current User is " +getpass.getuser()+".")

#printing the current date,time and the calendar of the month and year
#The str() function converts the specified value into a string
#To print the time in 12h format "%I:%M:%S %p", to print the time in 24h format "%H:%M:%S"
print("\nDate\t: " + str(datetime.now().date()))
print("Time\t: " + str(datetime.now().strftime("%I:%M:%S %p")))

print("\n\t==Calendar==")

#Printing the Calender of Current Month
print("\n"+calendar.month(datetime.now().year, datetime.now().month))

#Printing the OS Name
print("OS Name is " +os.name+".")

#Printing the OS Platform
print("\nOS Platform is " +platform.system()+".")

#Printing the OS Release Information
print("\nOS Release Info: " +platform.release()+".")

#Printing no of CPUs Device is Using
print("\nNumber Of CPUs system using is " + str(os.cpu_count())+".")


#Creating,Opening the output.log file
logFile = open("output.log", "w+")

#Used For Loop to go through all files in /system and it's sub directories
#os.fsdecode() decodes or decrypts from the error handler or the encoded file system of the operating system.
#os.path.join() join one or more path components intelligently
#logFile.close() used to close the file after writing is completed
for subdir, dirs, files in os.walk(os.fsencode('/system')):
    for file in files:
        if os.fsdecode(os.path.join(subdir, file)).endswith('.exe'):                    
            logFile.write(os.fsdecode(os.path.join(subdir, file)) + '\n')                  

logFile.close()
